/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.sql.Timestamp;


public class Instructors {
    private String InstructorID;
    private String InstructorName;
    private Timestamp BirthDate;
    private boolean Gender;
    private int ClassID;

    public Instructors() {
    }

    public Instructors(String InstructorID, String InstructorName, Timestamp BirthDate, boolean Gender, int ClassID) {
        this.InstructorID = InstructorID;
        this.InstructorName = InstructorName;
        this.BirthDate = BirthDate;
        this.Gender = Gender;
        this.ClassID = ClassID;
    }

    public String getInstructorID() {
        return InstructorID;
    }

    public void setInstructorID(String InstructorID) {
        this.InstructorID = InstructorID;
    }

    public String getInstructorName() {
        return InstructorName;
    }

    public void setInstructorName(String InstructorName) {
        this.InstructorName = InstructorName;
    }

    public Timestamp getBirthDate() {
        return BirthDate;
    }

    public void setBirthDate(Timestamp BirthDate) {
        this.BirthDate = BirthDate;
    }

    public boolean isGender() {
        return Gender;
    }

    public void setGender(boolean Gender) {
        this.Gender = Gender;
    }

    public int getClassID() {
        return ClassID;
    }

    public void setClassID(int ClassID) {
        this.ClassID = ClassID;
    }
    
    
}
