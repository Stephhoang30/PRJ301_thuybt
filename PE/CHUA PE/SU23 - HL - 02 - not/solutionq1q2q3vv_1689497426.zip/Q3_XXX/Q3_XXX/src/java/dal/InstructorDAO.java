/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import entity.Instructors;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class InstructorDAO  {

    protected  PreparedStatement statement;
    protected ResultSet resultSet;

    public InstructorDAO() {
    }

    public  List<Instructors> findAll() {
        List<Instructors> list = new ArrayList<>();
        DBContext dBContext = new DBContext();
        //sql
        String sql = "select * from Instructors";
        try {
            //chuan bi cho viec thuc th cau lenh
            statement = dBContext.connection.prepareStatement(sql);
            //thuc thi cau lenh
            resultSet = statement.executeQuery();
            //lay ra tung du lieu o tung dong` trong result set va them vao arraylist
            while (resultSet.next()) {
                //username
                String InstructorID = resultSet.getString("InstructorID");
                String InstructorName = resultSet.getString("InstructorName");
                Timestamp BirthDate = resultSet.getTimestamp("BirthDate");
                boolean gender = resultSet.getBoolean("Gender");
                int classId = resultSet.getInt("ClassID");
                
                Instructors instructors = new Instructors(InstructorID, InstructorName, BirthDate, gender, classId);
                list.add(instructors);
            }
            return list;
        } catch (SQLException e) {
            return null;
        } finally {
            try {
                if (dBContext.connection != null) {
                    dBContext.connection.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (resultSet != null) {
                    resultSet.close();
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
