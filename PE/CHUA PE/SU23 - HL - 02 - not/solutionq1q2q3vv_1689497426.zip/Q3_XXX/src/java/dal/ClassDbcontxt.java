/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Classs;

/**
 *
 * @author Khanh Manh
 */
public class ClassDbcontxt extends DBContext{

    public ArrayList<Classs> getAll() {
        ArrayList<Classs> Classss = new ArrayList<>();
        try {
            
            String sql = "SELECT * FROM [Classes]";
            PreparedStatement stm = connection.prepareStatement(sql);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {                
                Classs a = new Classs(rs.getInt(1),rs.getString(2),rs.getDate(3));
                Classss.add(a);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassDbcontxt.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Classss;
    }
    
}
