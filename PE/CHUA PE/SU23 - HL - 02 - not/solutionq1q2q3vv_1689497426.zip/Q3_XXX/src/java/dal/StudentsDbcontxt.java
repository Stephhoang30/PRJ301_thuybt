/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Students;

/**
 *
 * @author Khanh Manh
 */
public class StudentsDbcontxt extends DBContext{

    public ArrayList<Students> getAll() {
        ArrayList<Students> Instructorss = new ArrayList<>();
        try {
            
            String sql = "SELECT * FROM [Students]";
            PreparedStatement stm = connection.prepareStatement(sql);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {                
                Students a = new Students(rs.getString(1),rs.getString(2),rs.getDate(3),rs.getBoolean(4),rs.getInt(5));
                Instructorss.add(a);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassDbcontxt.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Instructorss;
    }
    
}
