/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

package controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author stephhoang
 */
public class Q1Servlet extends HttpServlet {
   
    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Q1Servlet</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Q1Servlet at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        request.getRequestDispatcher("displayForm.jsp").forward(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String firstStr = request.getParameter("first");
        String secondStr = request.getParameter("second");
        String action = request.getParameter("action");

        try {
            if (firstStr == null || secondStr == null || firstStr.isEmpty() || secondStr.isEmpty()) {
                response.getWriter().println("10_HoangCongThanh_Q1: Enter 2 number");
            } else {
                int first = Integer.parseInt(firstStr);
                int second = Integer.parseInt(secondStr);

                if ("Division".equals(action) && second == 0) {
                    response.getWriter().println("10_HoangCongThanh_Q1: Divide by zero error");
                } else {
                    double result = 0;
                    switch (action) {
                        case "Sum":
                            result = first + second;
                            response.getWriter().println("Result: " + result);
                            break;
                        case "Substract":
                            result = first - second;
                            response.getWriter().println("Result: " + result);
                            break;
                        case "Product":
                            result = first * second;
                            response.getWriter().println("Result: " + result);
                            break;
                        case "Division":
                            result = (double) first / second;
                            response.getWriter().printf("Result:%.2f",result);
                            break;
                    }
                }
            }
        } catch (NumberFormatException e) {
            response.getWriter().println("10_HoangCongThanh_Q1: Invalid number. Please enter Integer.");
        }
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
